from django.apps import AppConfig


class Amdin1Config(AppConfig):
    name = 'amdin1'
